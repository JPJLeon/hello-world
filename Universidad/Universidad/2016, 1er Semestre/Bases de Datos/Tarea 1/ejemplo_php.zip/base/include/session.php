<?
  session_start(); # Permite el acceso a las variables de sesión
?>
