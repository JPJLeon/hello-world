README
ATENCION, NOTA SUMAMENTE IMPORTANTE: para el ejercicio 3 de la ronda 1
la matriz se creo como una LISTA DE COLUMNAS (pues se me hacia mas facil
verlo de esta manera) en vez de una lista de filas, o sea, la primera lista
es la columna 0, la segunda es la columna 1,... etc, y los elementos dentro
de estas listas son cada uno de una fila distinta. Es por esto que quizas
no entiendan por que la matriz modificada con set se ve distinta, pero es la misma
solo que escrita de otra manera.

otra nota importante para algunos de los ejercicios: hay varias funciones 
que se definen de la forma funcion ______NoFinal, esto es pues esta version
pide algunos valores predeterminados para poder ejecutarse (por ejemplo lv
son listas vacias y los contadores auxiliares) que se dan por defecto en
la version final de la funcion.

para el primer ejercicio, simplemente convertimos el string a una lista
y luego llamamos a la funcion repetidas veces hasta llegar a que esta
esta vacia y comenzamos a agregar elementos, desde el ultimo hasta el primero
a una lista vacia y luego la convertimos en un string.

para el segundo problema simplemente hice una lista de listas, donde las "tuplas"
del diccionario eran cada una una sublista de la lista principal. Para hacer el
get solo tuve que recorrer la lista principal y revisar si el key era el mismo
para luego devolver ese valor.

el tercer problema fue el mas largo pues tenia mas funciones. De partida para crear
la matriz se definio la funcion crearColumna para asi crear de una cada columna necesaria
para agregar a la lista (matriz). Para hacer el set lo que se hizo fue copiar cada uno
de los valores de la matriz original en otra lista hasta encontrar el valor donde
los contadores de i y j coincidieran, luego se agrega el valor a cambiar. Al final
la matriz entregada por el matrix.set estava dada vuelta (incluyendo orden de columnas 
y el orden de las filas dentro de las columnas) por lo que defini la funcion reverse
para dar vuelta las listas y resolver este problema. El matrix.get es parecido en idea
a como funciona el diccionario, solo que revisamos si los contadores de i y j coinciden.