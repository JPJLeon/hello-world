def EQ(A, B):
    return A == B


def NEQ(A, B):
    return not(A == B)


def LT(A, B):
    return A < B


def GT(A, B):
    return A > B


def LEQ(A, B):
    return A <= B


def GEQ(A, B):
    return A >= B


def ADD(A, B):
    return A + B


def SUB(A, B):
    return A - B


def INPUT():
    return int(raw_input("lol: "))


def OUTPUT(OUT):
    print(OUT)
