Para el ejercicio 1 se hicieron las funciones prodA, prodB
y prodC que corresponden a las soluciones A, B y C respectivamente.
En el A se hizo una recursion simple, sin considerar la optimizacion 
como se menciono el tip, mientras que en la solucion B y C se revisa
si se tiene un 0 para asi devolver inmediatamente el valor 0. Para llamar
a la solucion C se hace de la manera (prodC lista (lambda (x) x)).

Similarmente para el ejercicio 2, tambien se dividen en soluciones A
y B. En ambas soluciones se revisa si el valor que se tiene es "e"
puesto que cuando se encuentra este valor no tiene sentido seguir
avanzando en la lista pues no existe algun edificio mas alto. Aqui
la estrategia era partir por una altura maxima 0 la cual cambiaba
cada vez que encontrabamos un edificio mas alto y se le sumaba 1
a la cantidad de edificios visibles.

Para el problema 3, la explicacion se dejo como comentario en el 
archivo r2e3.scm.