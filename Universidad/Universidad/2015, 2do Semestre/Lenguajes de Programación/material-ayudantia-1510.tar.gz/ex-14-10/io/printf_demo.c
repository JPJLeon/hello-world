#include <stdio.h>

int main(int argc, char const *argv[])
{
    printf("Simple hello world\n");

    int i = 0;
    printf("Number: %d\n", i);

    char string[] = "Hello!";
    printf("Texto: %s\n", string);

    return 0;
}
