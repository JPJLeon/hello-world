/** @file fountains.c
 *  @brief Compute number of block fountains of base @a n
 *	   by the recursion
 */

#include <stdio.h>
#include <stdlib.h>

#define N 15

int f[N];

int main()
{
	int n, k;

	f[0] = 1;
	for(n = 1; n < N; n++) {
		f[n] = 1;
		for(k = 1; k <= n; k++)
			f[n] += (n - k) * f[k];
	}

	for(n = 0; n < N; n++)
		printf(" %d", f[n]);
	printf("\n");

	exit(EXIT_SUCCESS);
}
