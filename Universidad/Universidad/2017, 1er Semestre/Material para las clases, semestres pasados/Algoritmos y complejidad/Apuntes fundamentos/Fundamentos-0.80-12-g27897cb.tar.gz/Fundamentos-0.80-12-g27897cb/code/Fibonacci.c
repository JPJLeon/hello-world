/** @file Fibonacci.c
 *  @brief Compute first Fibonacci numbers
 */

#include <stdio.h>
#include <stdlib.h>

#define N 21

int F[N];

int main()
{
	int n;

	F[0] = 0; F[1] = 1;
	for(n = 2; n < N; n++)
		F[n] = F[n - 1] + F[n - 2];

	for(n = 0; n < N; n++)
		printf(" %d", F[n]);
	printf("\n");

	exit(EXIT_SUCCESS);
}
