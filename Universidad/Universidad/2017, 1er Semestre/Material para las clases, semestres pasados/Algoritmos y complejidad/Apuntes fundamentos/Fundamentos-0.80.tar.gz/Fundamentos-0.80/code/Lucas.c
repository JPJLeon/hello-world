/** @file Lucas.c
 *  @brief Compute first Lucas numbers
 */

#include <stdio.h>
#include <stdlib.h>

#define N 21

int L[N];

int main()
{
	int n;

	L[0] = 2; L[1] = 1;
	for(n = 2; n < N; n++)
		L[n] = L[n - 1] + L[n - 2];

	for(n = 0; n < N; n++)
		printf(" %d", L[n]);
	printf("\n");

	exit(EXIT_SUCCESS);
}
