#ifndef _MATCHER_H_
#define _MATCHER_H_

int match(char *, char *);
int matchhere(char *, char *);
int matchstar(int, char *, char *);

#endif //_MATCHER_H_