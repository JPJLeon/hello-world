#include <stdio.h>
#include <string.h>

#include "matcher.h"

#define MAX_BUFF 1000

int main()
{
	char RE_buffer[MAX_BUFF];
	char TXT_buffer[MAX_BUFF];

	for(;;) {
		printf("Ingrese patrón a buscar: ");
		fgets(RE_buffer, sizeof(RE_buffer), stdin);
		RE_buffer[strlen(RE_buffer) - 1] = '\0';

		printf("Ingrese texto: ");
		fgets(TXT_buffer, sizeof(TXT_buffer), stdin);

		if(match(RE_buffer, TXT_buffer))
			printf("Calza\n");
		else
			printf("No calza\n");
	};

	return 0;
}
